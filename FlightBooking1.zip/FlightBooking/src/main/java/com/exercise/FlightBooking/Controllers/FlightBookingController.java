package com.exercise.FlightBooking.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.exercise.FlightBooking.Entities.Airline;
//import com.exercise.FlightBooking.Entities.User;
import com.exercise.FlightBooking.Services.FlightBookingService;

@RestController
@RequestMapping("/api/v1.0")
public class FlightBookingController {
	@Autowired
	private FlightBookingService serv;
	
	@PostMapping("/airlines")
	public Airline createAirline(@RequestBody Airline airline){
		return serv.saveAirline(airline);
	}
	
//	@RequestMapping("/admin/login")
//	public String adminLogin(){
//		return "Hello";
	//}
	@GetMapping("/flight/search")
	public List<Airline> allMovies(){
		return serv.findAllAirlines();
	}
//	@PostMapping("/flight/booking/{flightid}")
//	public User bookTicket(){
//		return null;
//	}
//	
//	@GetMapping("/flight/ticket/{pnr}")
//	public User getTicket(@PathVariable long pnr){
//		return null;//service.
//	}
//	@GetMapping("/flight/tickets/{emailId}")
//	public User getTickets(){
//		return null;
//	}
//	
//	@DeleteMapping("/flight/cancel/{pnr}")
//	public User cancelTicket(@PathVariable long pnr){
//		return null;
//	}

}
