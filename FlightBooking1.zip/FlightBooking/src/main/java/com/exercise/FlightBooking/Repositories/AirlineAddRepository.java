package com.exercise.FlightBooking.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.exercise.FlightBooking.Entities.Airline;

public interface AirlineAddRepository extends JpaRepository<Airline, Integer>{

}
