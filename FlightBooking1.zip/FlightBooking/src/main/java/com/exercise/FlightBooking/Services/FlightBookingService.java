package com.exercise.FlightBooking.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exercise.FlightBooking.Entities.Airline;
//import com.exercise.FlightBooking.Entities.User;
import com.exercise.FlightBooking.Repositories.AirlineAddRepository;
//import com.exercise.FlightBooking.Repositories.FlightBookingRepository;

@Service
public class FlightBookingService {
	
	@Autowired
	private AirlineAddRepository repos;
	
	
	public Airline saveAirline(Airline airline){
		return repos.save(airline);
		
	}
	public List<Airline> findAllAirlines(){
		return repos.findAll();
	}

}
