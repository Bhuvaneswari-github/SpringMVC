package com.exercise.FlightBooking.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

//import com.exercise.FlightBooking.Entities.User;

//public interface FlightBookingRepository extends JpaRepository<User, String>{

//}
